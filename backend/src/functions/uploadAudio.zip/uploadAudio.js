const { S3Client, PutObjectCommand } = require('@aws-sdk/client-s3')
const { v4: uuidv4 } = require('uuid')

const s3Client = new S3Client({ region: process.env.AWS_REGION || 'us-east-1' })

// Headers CORS para todas las respuestas
const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type,Authorization,X-Amz-Date,X-Api-Key,X-Amz-Security-Token',
  'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS'
}

exports.handler = async (event) => {
  try {
    console.log('Event:', JSON.stringify(event, null, 2))
    
    // Manejar preflight OPTIONS request
    if (event.httpMethod === 'OPTIONS') {
      return {
        statusCode: 200,
        headers: corsHeaders,
        body: ''
      }
    }

    // Verificar que sea una petición POST
    if (event.httpMethod !== 'POST') {
      return {
        statusCode: 405,
        headers: {
          'Content-Type': 'application/json',
          ...corsHeaders
        },
        body: JSON.stringify({
          error: 'Método no permitido'
        })
      }
    }

    // Parsear el body JSON
    let body
    try {
      body = JSON.parse(event.body)
    } catch (error) {
      return {
        statusCode: 400,
        headers: {
          'Content-Type': 'application/json',
          ...corsHeaders
        },
        body: JSON.stringify({
          error: 'Body JSON inválido',
          details: error.message
        })
      }
    }

    const { audioData, fileName, contentType, doctorId } = body

    if (!audioData || !fileName) {
      return {
        statusCode: 400,
        headers: {
          'Content-Type': 'application/json',
          ...corsHeaders
        },
        body: JSON.stringify({
          error: 'audioData y fileName son requeridos'
        })
      }
    }

    // Para testing: usar un ID de usuario temporal
    const userId = doctorId || 'test-user-demo'
    
    // Generar ID único para el archivo
    const fileId = uuidv4()
    const timestamp = new Date().toISOString()
    const key = `audio/${userId}/${fileId}/${fileName}`

    // Decodificar audio base64
    const audioBuffer = Buffer.from(audioData, 'base64')

    // Validar tamaño del archivo (máximo 50MB)
    if (audioBuffer.length > 50 * 1024 * 1024) {
      return {
        statusCode: 400,
        headers: {
          'Content-Type': 'application/json',
          ...corsHeaders
        },
        body: JSON.stringify({
          error: 'El archivo es demasiado grande. Máximo 50MB.'
        })
      }
    }

    // Subir a S3
    const uploadParams = {
      Bucket: process.env.AUDIO_BUCKET_NAME,
      Key: key,
      Body: audioBuffer,
      ContentType: contentType || 'audio/webm',
      Metadata: {
        'user-id': userId,
        'upload-time': timestamp,
        'original-filename': fileName,
        'demo-mode': 'true'
      }
    }

    const result = await s3Client.send(new PutObjectCommand(uploadParams))

    console.log(`Audio subido exitosamente: ${key}`)

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        ...corsHeaders
      },
      body: JSON.stringify({
        success: true,
        audioKey: key,
        fileId,
        fileName,
        uploadTime: timestamp,
        size: audioBuffer.length,
        message: 'Audio subido correctamente a S3',
        s3Response: result.ETag
      })
    }

  } catch (error) {
    console.error('Error en uploadAudio:', error)
    
    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
        ...corsHeaders
      },
      body: JSON.stringify({
        error: 'Error interno del servidor',
        message: error.message,
        stack: process.env.NODE_ENV === 'development' ? error.stack : undefined
      })
    }
  }
} 