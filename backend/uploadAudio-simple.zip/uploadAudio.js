// UploadAudio simplificado sin dependencias externas
exports.handler = async (event) => {
  console.log('=== UPLOAD AUDIO SIMPLIFICADO ===')
  console.log('Event:', JSON.stringify(event, null, 2))

  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type,Authorization,X-Amz-Date,X-Api-Key,X-Amz-Security-Token',
    'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS'
  }

  try {
    // Handle OPTIONS
    if (event.httpMethod === 'OPTIONS') {
      return {
        statusCode: 200,
        headers: corsHeaders,
        body: ''
      }
    }

    // Handle POST - versión simplificada
    if (event.httpMethod === 'POST') {
      console.log('Handling POST request for uploadAudio - SIMPLIFICADO')
      
      // Parsear body
      let body
      try {
        body = JSON.parse(event.body)
      } catch (error) {
        return {
          statusCode: 400,
          headers: {
            'Content-Type': 'application/json',
            ...corsHeaders
          },
          body: JSON.stringify({ error: 'Body inválido' })
        }
      }

      const { audioData, fileName, contentType, doctorId = 'doctor-demo' } = body

      if (!audioData) {
        return {
          statusCode: 400,
          headers: {
            'Content-Type': 'application/json',
            ...corsHeaders
          },
          body: JSON.stringify({ 
            error: 'audioData es requerido' 
          })
        }
      }

      // Generar key único para S3 (simulado)
      const audioKey = `audio/${doctorId}/${Date.now()}-${fileName || 'recording.wav'}`
      const timestamp = new Date().toISOString()

      console.log(`Simulando subida a S3: ${audioKey}`)

      // Simular validación de tamaño
      const audioBuffer = Buffer.from(audioData, 'base64')
      
      if (audioBuffer.length > 10 * 1024 * 1024) {
        return {
          statusCode: 400,
          headers: {
            'Content-Type': 'application/json',
            ...corsHeaders
          },
          body: JSON.stringify({ 
            error: 'Archivo demasiado grande (máximo 10MB)' 
          })
        }
      }

      // Simular respuesta exitosa
      console.log('Audio procesado exitosamente (simulado)')

      return {
        statusCode: 200,
        headers: {
          'Content-Type': 'application/json',
          ...corsHeaders
        },
        body: JSON.stringify({
          success: true,
          audioKey: audioKey,
          fileName: fileName || 'recording.wav',
          size: audioBuffer.length,
          uploadedAt: timestamp,
          doctorId: doctorId,
          s3ETag: 'simulated-etag-' + Date.now(),
          services: {
            storage: "Amazon S3 (SIMULADO - Listo para REAL)"
          }
        })
      }
    }

    // Other methods
    return {
      statusCode: 405,
      headers: {
        'Content-Type': 'application/json',
        ...corsHeaders
      },
      body: JSON.stringify({
        error: 'Method not allowed',
        method: event.httpMethod
      })
    }

  } catch (error) {
    console.error('UPLOAD AUDIO SIMPLIFICADO ERROR:', error)
    console.error('Stack:', error.stack)
    
    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
        ...corsHeaders
      },
      body: JSON.stringify({
        error: 'Internal server error',
        message: error.message,
        timestamp: new Date().toISOString()
      })
    }
  }
} 