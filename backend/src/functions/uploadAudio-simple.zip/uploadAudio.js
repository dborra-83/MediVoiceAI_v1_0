// Headers CORS para todas las respuestas
const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type,Authorization,X-Amz-Date,X-Api-Key,X-Amz-Security-Token',
  'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS'
}

exports.handler = async (event) => {
  try {
    console.log('Event recibido:', JSON.stringify(event, null, 2))
    
    // Manejar preflight OPTIONS request
    if (event.httpMethod === 'OPTIONS') {
      return {
        statusCode: 200,
        headers: corsHeaders,
        body: ''
      }
    }

    // Verificar que sea una petición POST
    if (event.httpMethod !== 'POST') {
      return {
        statusCode: 405,
        headers: {
          'Content-Type': 'application/json',
          ...corsHeaders
        },
        body: JSON.stringify({
          error: 'Método no permitido'
        })
      }
    }

    // Parsear el body JSON
    let body
    try {
      body = JSON.parse(event.body)
    } catch (error) {
      return {
        statusCode: 400,
        headers: {
          'Content-Type': 'application/json',
          ...corsHeaders
        },
        body: JSON.stringify({
          error: 'Body JSON inválido',
          details: error.message
        })
      }
    }

    console.log('Body parseado:', body)

    // VERSIÓN SIMPLIFICADA - Solo simular éxito
    const { audioData, fileName, contentType, doctorId } = body

    if (!audioData || !fileName) {
      return {
        statusCode: 400,
        headers: {
          'Content-Type': 'application/json',
          ...corsHeaders
        },
        body: JSON.stringify({
          error: 'audioData y fileName son requeridos'
        })
      }
    }

    // Simular respuesta exitosa SIN subir a S3
    const fileId = 'temp-' + Date.now()
    const key = `temp/audio/${fileId}/${fileName}`

    console.log('Simulando subida exitosa para:', key)

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        ...corsHeaders
      },
      body: JSON.stringify({
        success: true,
        audioKey: key,
        fileId,
        fileName,
        uploadTime: new Date().toISOString(),
        size: audioData.length,
        message: '✅ Audio procesado temporalmente (sin S3)',
        mode: 'simplified-test'
      })
    }

  } catch (error) {
    console.error('Error en uploadAudio (simplificado):', error)
    
    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
        ...corsHeaders
      },
      body: JSON.stringify({
        error: 'Error interno del servidor',
        message: error.message,
        stack: error.stack // Para debug
      })
    }
  }
} 