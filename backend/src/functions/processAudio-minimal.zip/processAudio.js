// Ultra minimal processAudio function
exports.handler = async (event) => {
  console.log('=== ULTRA MINIMAL PROCESS ===')
  console.log('Event:', JSON.stringify(event, null, 2))

  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type,Authorization,X-Amz-Date,X-Api-Key,X-Amz-Security-Token',
    'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS'
  }

  try {
    // Handle OPTIONS
    if (event.httpMethod === 'OPTIONS') {
      return {
        statusCode: 200,
        headers: corsHeaders,
        body: ''
      }
    }

    // Handle POST - ultra simple
    if (event.httpMethod === 'POST') {
      return {
        statusCode: 200,
        headers: {
          'Content-Type': 'application/json',
          ...corsHeaders
        },
        body: JSON.stringify({
          success: true,
          transcription: "El paciente presenta dolor abdominal agudo en cuadrante inferior derecho, fiebre de 39 grados celsius, náuseas y vómitos desde hace 12 horas. Refiere dolor tipo cólico que se intensifica con la palpación.",
          analysis: {
            symptoms: [
              "dolor abdominal agudo",
              "fiebre de 39°C", 
              "náuseas",
              "vómitos",
              "dolor tipo cólico"
            ],
            vitalSigns: {
              temperature: "39°C",
              location: "cuadrante inferior derecho"
            },
            recommendations: [
              "Evaluación quirúrgica urgente",
              "Solicitar hemograma completo y PCR",
              "TC de abdomen con contraste",
              "NPO (ayuno absoluto)",
              "Acceso venoso y hidratación IV",
              "Analgesia según protocolo",
              "Monitoreo de signos vitales cada 2 horas"
            ],
            diagnosis: "Sospecha de apendicitis aguda",
            urgency: "ALTA - Requiere evaluación inmediata",
            specialty: "Cirugía General"
          },
          processedAt: new Date().toISOString(),
          processingTime: "2.3 segundos",
          services: {
            transcription: "Amazon Transcribe Medical (simulado)",
            analysis: "Amazon Bedrock Claude 3 Sonnet (simulado)"
          },
          message: 'Ultra minimal process test passed!',
          eventKeys: Object.keys(event)
        })
      }
    }

    // Other methods
    return {
      statusCode: 405,
      headers: {
        'Content-Type': 'application/json',
        ...corsHeaders
      },
      body: JSON.stringify({
        error: 'Method not allowed',
        method: event.httpMethod
      })
    }

  } catch (error) {
    console.error('ULTRA MINIMAL PROCESS ERROR:', error)
    
    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
        ...corsHeaders
      },
      body: JSON.stringify({
        error: 'Internal server error',
        message: error.message,
        timestamp: new Date().toISOString()
      })
    }
  }
} 