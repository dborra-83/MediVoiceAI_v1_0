// Ultra-simple function for CORS debugging
exports.handler = async (event) => {
  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type,Authorization,X-Amz-Date,X-Api-Key,X-Amz-Security-Token',
    'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS'
  }

  console.log('=== ULTRA SIMPLE DEBUG ===')
  console.log('httpMethod:', event.httpMethod)
  console.log('headers:', JSON.stringify(event.headers))
  console.log('body:', event.body)

  try {
    // Handle OPTIONS
    if (event.httpMethod === 'OPTIONS') {
      console.log('Handling OPTIONS request')
      return {
        statusCode: 200,
        headers: corsHeaders,
        body: ''
      }
    }

    // Handle POST with minimal processing
    if (event.httpMethod === 'POST') {
      console.log('Handling POST request')
      
      return {
        statusCode: 200,
        headers: {
          'Content-Type': 'application/json',
          ...corsHeaders
        },
        body: JSON.stringify({
          success: true,
          message: '✅ Ultra-simple test passed!',
          httpMethod: event.httpMethod,
          timestamp: new Date().toISOString(),
          debug: 'minimal-function'
        })
      }
    }

    // Other methods
    console.log('Method not allowed:', event.httpMethod)
    return {
      statusCode: 405,
      headers: {
        'Content-Type': 'application/json',
        ...corsHeaders
      },
      body: JSON.stringify({
        error: 'Method not allowed',
        method: event.httpMethod
      })
    }

  } catch (error) {
    console.error('ULTRA SIMPLE ERROR:', error)
    console.error('Stack:', error.stack)
    
    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
        ...corsHeaders
      },
      body: JSON.stringify({
        error: 'Internal server error',
        message: error.message,
        timestamp: new Date().toISOString()
      })
    }
  }
} 