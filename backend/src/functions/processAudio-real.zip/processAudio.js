const { S3Client, GetObjectCommand } = require('@aws-sdk/client-s3')
const { TranscribeClient, StartMedicalTranscriptionJobCommand, GetMedicalTranscriptionJobCommand } = require('@aws-sdk/client-transcribe')
const { BedrockRuntimeClient, InvokeModelCommand } = require('@aws-sdk/client-bedrock-runtime')
const { DynamoDBClient } = require('@aws-sdk/client-dynamodb')
const { DynamoDBDocumentClient, PutCommand, GetCommand } = require('@aws-sdk/lib-dynamodb')
const { v4: uuidv4 } = require('uuid')

const s3Client = new S3Client({ region: process.env.AWS_REGION || 'us-east-1' })
const transcribeClient = new TranscribeClient({ region: process.env.AWS_REGION || 'us-east-1' })
const bedrockClient = new BedrockRuntimeClient({ region: process.env.AWS_REGION || 'us-east-1' })
const dynamoClient = DynamoDBDocumentClient.from(new DynamoDBClient({ region: process.env.AWS_REGION || 'us-east-1' }))

// Función auxiliar para esperar completación de transcripción
const waitForTranscription = async (jobName, maxAttempts = 30) => {
  for (let attempt = 0; attempt < maxAttempts; attempt++) {
    const response = await transcribeClient.send(
      new GetMedicalTranscriptionJobCommand({ MedicalTranscriptionJobName: jobName })
    )
    
    const status = response.MedicalTranscriptionJob.TranscriptionJobStatus
    
    if (status === 'COMPLETED') {
      return response.MedicalTranscriptionJob
    } else if (status === 'FAILED') {
      throw new Error(`Transcripción falló: ${response.MedicalTranscriptionJob.FailureReason}`)
    }
    
    // Esperar 10 segundos antes del siguiente intento
    await new Promise(resolve => setTimeout(resolve, 10000))
  }
  
  throw new Error('Timeout esperando completación de transcripción')
}

// Función auxiliar para obtener prompt personalizado
const getPromptBySpecialty = async (specialty = 'general') => {
  try {
    const response = await dynamoClient.send(new GetCommand({
      TableName: process.env.PROMPTS_TABLE,
      Key: {
        prompt_id: `${specialty}-prompt`,
        specialty: specialty
      }
    }))
    
    return response.Item?.content || getDefaultPrompt()
  } catch (error) {
    console.error('Error obteniendo prompt:', error)
    return getDefaultPrompt()
  }
}

const getDefaultPrompt = () => {
  return `Eres un asistente médico especializado. Analiza la siguiente transcripción de una consulta médica y genera:

1. RESUMEN CLÍNICO:
- Motivo de consulta
- Síntomas principales
- Antecedentes relevantes
- Examen físico (si aplica)

2. IMPRESIÓN DIAGNÓSTICA:
- Diagnóstico principal
- Diagnósticos diferenciales

3. PLAN TERAPÉUTICO:
- Medicamentos con dosis exactas
- Duración del tratamiento
- Indicaciones especiales
- Controles sugeridos

Transcripción: {transcription}`
}

exports.handler = async (event) => {
  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type,Authorization,X-Amz-Date,X-Api-Key,X-Amz-Security-Token',
    'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS'
  }

  console.log('=== PROCESS AUDIO REAL - AMAZON TRANSCRIBE + BEDROCK ===')
  console.log('httpMethod:', event.httpMethod)
  console.log('body:', event.body)

  try {
    // Handle OPTIONS
    if (event.httpMethod === 'OPTIONS') {
      console.log('Handling OPTIONS request for processAudio')
      return {
        statusCode: 200,
        headers: corsHeaders,
        body: ''
      }
    }

    // Handle POST with real AI processing
    if (event.httpMethod === 'POST') {
      console.log('Handling POST request for processAudio - REAL AI')
      
      // Parsear body
      let body
      try {
        body = JSON.parse(event.body)
      } catch (error) {
        return {
          statusCode: 400,
          headers: {
            'Content-Type': 'application/json',
            ...corsHeaders
          },
          body: JSON.stringify({ error: 'Body inválido' })
        }
      }

      const { audioKey, patientId = 'patient-demo', doctorId = 'doctor-demo', specialty = 'general' } = body

      if (!audioKey) {
        return {
          statusCode: 400,
          headers: {
            'Content-Type': 'application/json',
            ...corsHeaders
          },
          body: JSON.stringify({ 
            error: 'audioKey es requerido' 
          })
        }
      }

      // Generar IDs únicos
      const consultationId = uuidv4()
      const transcriptionJobName = `medivoice-${consultationId}-${Date.now()}`
      const timestamp = new Date().toISOString()

      console.log(`Iniciando transcripción médica REAL: ${transcriptionJobName}`)

      // Iniciar transcripción médica REAL
      const transcriptionParams = {
        MedicalTranscriptionJobName: transcriptionJobName,
        LanguageCode: 'es-ES',
        MediaFormat: 'wav',
        Media: {
          MediaFileUri: `s3://${process.env.AUDIO_BUCKET_NAME}/${audioKey}`
        },
        OutputBucketName: process.env.AUDIO_BUCKET_NAME,
        OutputKey: `transcriptions/${consultationId}/`,
        Specialty: 'PRIMARYCARE',
        Type: 'CONVERSATION',
        Settings: {
          ShowSpeakerLabels: true,
          MaxSpeakerLabels: 2,
          ShowAlternatives: false
        }
      }

      await transcribeClient.send(new StartMedicalTranscriptionJobCommand(transcriptionParams))
      console.log('Trabajo de transcripción REAL iniciado exitosamente')

      // Esperar completación de transcripción
      const completedJob = await waitForTranscription(transcriptionJobName)
      console.log('Transcripción REAL completada, obteniendo resultado...')

      // Obtener transcripción desde S3
      const transcriptionKey = completedJob.Transcript.TranscriptFileUri.split('.amazonaws.com/')[1]
      const transcriptionResponse = await s3Client.send(new GetObjectCommand({
        Bucket: process.env.AUDIO_BUCKET_NAME,
        Key: transcriptionKey
      }))

      const transcriptionData = JSON.parse(await transcriptionResponse.Body.transformToString())
      const transcriptionText = transcriptionData.results.transcripts[0].transcript

      console.log('Transcripción REAL obtenida, procesando con Bedrock Claude 3...')

      // Obtener prompt personalizado
      const promptTemplate = await getPromptBySpecialty(specialty)
      const prompt = promptTemplate.replace('{transcription}', transcriptionText)

      // Procesar con Bedrock Claude 3 REAL
      const bedrockParams = {
        modelId: process.env.BEDROCK_MODEL_ID,
        contentType: 'application/json',
        accept: 'application/json',
        body: JSON.stringify({
          anthropic_version: "bedrock-2023-05-31",
          max_tokens: 4000,
          messages: [
            {
              role: "user",
              content: prompt
            }
          ]
        })
      }

      const bedrockResponse = await bedrockClient.send(new InvokeModelCommand(bedrockParams))
      const responseBody = JSON.parse(new TextDecoder().decode(bedrockResponse.body))
      const aiAnalysis = responseBody.content[0].text

      console.log('Análisis de IA REAL completado, guardando en base de datos...')

      // Guardar consulta en DynamoDB
      const consultationData = {
        consultation_id: consultationId,
        doctor_id: doctorId,
        patient_id: patientId,
        audio_key: audioKey,
        transcription: transcriptionText,
        ai_analysis: aiAnalysis,
        specialty: specialty,
        created_at: timestamp,
        updated_at: timestamp,
        status: 'completed',
        transcription_job_name: transcriptionJobName
      }

      await dynamoClient.send(new PutCommand({
        TableName: process.env.CONSULTATIONS_TABLE,
        Item: consultationData
      }))

      console.log(`Consulta guardada exitosamente: ${consultationId}`)

      return {
        statusCode: 200,
        headers: {
          'Content-Type': 'application/json',
          ...corsHeaders
        },
        body: JSON.stringify({
          success: true,
          consultationId,
          transcription: transcriptionText,
          aiAnalysis,
          timestamp,
          patientId,
          doctorId,
          specialty,
          services: {
            transcription: "Amazon Transcribe Medical (REAL)",
            analysis: "Amazon Bedrock Claude 3 Sonnet (REAL)"
          }
        })
      }
    }

    // Other methods
    console.log('Method not allowed:', event.httpMethod)
    return {
      statusCode: 405,
      headers: {
        'Content-Type': 'application/json',
        ...corsHeaders
      },
      body: JSON.stringify({
        error: 'Method not allowed',
        method: event.httpMethod
      })
    }

  } catch (error) {
    console.error('PROCESS AUDIO REAL ERROR:', error)
    console.error('Stack:', error.stack)
    
    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
        ...corsHeaders
      },
      body: JSON.stringify({
        error: 'Internal server error',
        message: error.message,
        timestamp: new Date().toISOString()
      })
    }
  }
} 