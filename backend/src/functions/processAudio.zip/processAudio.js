const { S3Client, GetObjectCommand } = require('@aws-sdk/client-s3')
const { TranscribeClient, StartMedicalTranscriptionJobCommand, GetMedicalTranscriptionJobCommand } = require('@aws-sdk/client-transcribe')
const { BedrockRuntimeClient, InvokeModelCommand } = require('@aws-sdk/client-bedrock-runtime')
const { DynamoDBClient } = require('@aws-sdk/client-dynamodb')
const { DynamoDBDocumentClient, PutCommand, GetCommand } = require('@aws-sdk/lib-dynamodb')
const { v4: uuidv4 } = require('uuid')

const s3Client = new S3Client({ region: process.env.AWS_REGION || 'us-east-1' })
const transcribeClient = new TranscribeClient({ region: process.env.AWS_REGION || 'us-east-1' })
const bedrockClient = new BedrockRuntimeClient({ region: process.env.AWS_REGION || 'us-east-1' })
const dynamoClient = DynamoDBDocumentClient.from(new DynamoDBClient({ region: process.env.AWS_REGION || 'us-east-1' }))

// Helper function to wait for transcription job completion
const waitForTranscriptionCompletion = async (jobName, maxWaitTime = 300000) => {
  const startTime = Date.now()
  
  while (Date.now() - startTime < maxWaitTime) {
    const response = await transcribeClient.send(new GetMedicalTranscriptionJobCommand({
      MedicalTranscriptionJobName: jobName
    }))
    
    const status = response.MedicalTranscriptionJob.TranscriptionJobStatus
    
    if (status === 'COMPLETED') {
      return response.MedicalTranscriptionJob
    } else if (status === 'FAILED') {
      throw new Error(`Transcription job failed: ${response.MedicalTranscriptionJob.FailureReason}`)
    }
    
    // Wait 5 seconds before checking again
    await new Promise(resolve => setTimeout(resolve, 5000))
  }
  
  throw new Error('Transcription job timed out')
}

// Helper function to get medical prompt based on specialty
const getMedicalPrompt = async (specialty) => {
  try {
    const response = await dynamoClient.send(new GetCommand({
      TableName: process.env.PROMPTS_TABLE,
      Key: { 
        prompt_id: 'medical-analysis',
        specialty: specialty || 'general'
      }
    }))
    
    if (response.Item) {
      return response.Item.content
    }
  } catch (error) {
    console.warn('Could not fetch custom prompt, using default:', error)
  }
  
  // Default medical analysis prompt
  return `Como médico especialista, analiza la siguiente transcripción de una consulta médica y proporciona:

1. RESUMEN CLÍNICO:
   - Motivo de consulta principal
   - Síntomas presentes
   - Antecedentes relevantes mencionados

2. IMPRESIÓN DIAGNÓSTICA:
   - Diagnóstico principal probable
   - Diagnósticos diferenciales a considerar
   - Nivel de urgencia (bajo/medio/alto)

3. PLAN TERAPÉUTICO:
   - Medicamentos recomendados (con dosis específicas)
   - Exámenes complementarios necesarios
   - Recomendaciones de seguimiento

4. OBSERVACIONES:
   - Signos de alarma a vigilar
   - Recomendaciones al paciente
   - Próxima cita sugerida

Mantén un lenguaje médico profesional pero comprensible. Si la información es insuficiente, indícalo claramente.

Transcripción a analizar:`
}

exports.handler = async (event) => {
  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type,Authorization,X-Amz-Date,X-Api-Key,X-Amz-Security-Token',
    'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS'
  }

  console.log('=== PROCESS AUDIO WITH AWS SERVICES ===')
  console.log('httpMethod:', event.httpMethod)

  try {
    // Handle OPTIONS preflight request
    if (event.httpMethod === 'OPTIONS') {
      return {
        statusCode: 200,
        headers: corsHeaders,
        body: ''
      }
    }

    // Handle POST request
    if (event.httpMethod === 'POST') {
      console.log('Processing audio with AWS Transcribe Medical and Bedrock')
      
      // Parse request body
      let body
      try {
        body = JSON.parse(event.body)
      } catch (error) {
        console.error('Error parsing body:', error)
        return {
          statusCode: 400,
          headers: {
            'Content-Type': 'application/json',
            ...corsHeaders
          },
          body: JSON.stringify({ error: 'Invalid JSON body' })
        }
      }

      const { audioKey, patientId, doctorId, specialty = 'general' } = body

      if (!audioKey) {
        return {
          statusCode: 400,
          headers: {
            'Content-Type': 'application/json',
            ...corsHeaders
          },
          body: JSON.stringify({ 
            error: 'audioKey is required' 
          })
        }
      }

      // Get user info from authorizer (if available)
      const user = event.requestContext?.authorizer?.claims
      const userId = user?.sub || 'anonymous'
      const currentDoctorId = doctorId || userId
      const currentPatientId = patientId || `patient-${Date.now()}`
      
      const consultationId = uuidv4()
      const timestamp = new Date().toISOString()

      console.log(`Processing audio: ${audioKey}`)

      // 1. Start Amazon Transcribe Medical job
      const jobName = `transcription-${consultationId}`
      const s3Uri = `s3://${process.env.AUDIO_BUCKET_NAME}/${audioKey}`

      console.log('Starting Transcribe Medical job:', jobName)

      await transcribeClient.send(new StartMedicalTranscriptionJobCommand({
        MedicalTranscriptionJobName: jobName,
        LanguageCode: 'es-ES', // Spanish
        Specialty: 'PRIMARYCARE',
        Type: 'CONVERSATION',
        Media: {
          MediaFileUri: s3Uri
        },
        OutputBucketName: process.env.AUDIO_BUCKET_NAME,
        OutputKey: `transcriptions/${consultationId}.json`,
        Settings: {
          ShowSpeakerLabels: true,
          MaxSpeakerLabels: 2
        }
      }))

      // 2. Wait for transcription completion
      console.log('Waiting for transcription completion...')
      const transcriptionJob = await waitForTranscriptionCompletion(jobName)
      
      // 3. Get transcription results from S3
      const transcriptionKey = `transcriptions/${consultationId}.json`
      const transcriptionResponse = await s3Client.send(new GetObjectCommand({
        Bucket: process.env.AUDIO_BUCKET_NAME,
        Key: transcriptionKey
      }))

      const transcriptionData = JSON.parse(await transcriptionResponse.Body.transformToString())
      const transcriptionText = transcriptionData.results.transcripts[0].transcript

      console.log('Transcription completed:', transcriptionText.substring(0, 100) + '...')

      // 4. Get medical prompt based on specialty
      const medicalPrompt = await getMedicalPrompt(specialty)

      // 5. Analyze with Amazon Bedrock (Claude 3 Sonnet)
      console.log('Analyzing with Amazon Bedrock Claude 3 Sonnet...')
      
      const bedrockPayload = {
        anthropic_version: "bedrock-2023-05-31",
        max_tokens: 2000,
        messages: [
          {
            role: "user",
            content: `${medicalPrompt}\n\n${transcriptionText}`
          }
        ]
      }

      const bedrockResponse = await bedrockClient.send(new InvokeModelCommand({
        modelId: process.env.BEDROCK_MODEL_ID || 'anthropic.claude-3-sonnet-20240229-v1:0',
        contentType: 'application/json',
        body: JSON.stringify(bedrockPayload)
      }))

      const aiAnalysisResult = JSON.parse(new TextDecoder().decode(bedrockResponse.body))
      const aiAnalysis = aiAnalysisResult.content[0].text

      console.log('AI analysis completed')

      // 6. Save consultation to DynamoDB
      const consultationData = {
        consultation_id: consultationId,
        doctor_id: currentDoctorId,
        patient_id: currentPatientId,
        audio_key: audioKey,
        transcription: transcriptionText,
        ai_analysis: aiAnalysis,
        specialty: specialty,
        status: 'completed',
        created_at: timestamp,
        updated_at: timestamp
      }

      await dynamoClient.send(new PutCommand({
        TableName: process.env.CONSULTATIONS_TABLE,
        Item: consultationData
      }))

      console.log('Consultation saved to DynamoDB:', consultationId)

      return {
        statusCode: 200,
        headers: {
          'Content-Type': 'application/json',
          ...corsHeaders
        },
        body: JSON.stringify({
          success: true,
          consultationId,
          transcription: transcriptionText,
          aiAnalysis: aiAnalysis,
          timestamp,
          patientId: currentPatientId,
          doctorId: currentDoctorId,
          specialty,
          services: {
            transcription: "Amazon Transcribe Medical",
            analysis: "Amazon Bedrock Claude 3 Sonnet",
            storage: "Amazon DynamoDB"
          }
        })
      }
    }

    // Method not allowed
    return {
      statusCode: 405,
      headers: {
        'Content-Type': 'application/json',
        ...corsHeaders
      },
      body: JSON.stringify({
        error: 'Method not allowed',
        method: event.httpMethod
      })
    }

  } catch (error) {
    console.error('PROCESS AUDIO ERROR:', error)
    console.error('Stack:', error.stack)
    
    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
        ...corsHeaders
      },
      body: JSON.stringify({
        error: 'Internal server error',
        message: error.message,
        timestamp: new Date().toISOString(),
        details: process.env.NODE_ENV === 'development' ? error.stack : undefined
      })
    }
  }
} 