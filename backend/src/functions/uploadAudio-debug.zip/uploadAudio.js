const { S3Client, PutObjectCommand } = require('@aws-sdk/client-s3')
const { v4: uuidv4 } = require('uuid')

const s3Client = new S3Client({ region: process.env.AWS_REGION || 'us-east-1' })

exports.handler = async (event) => {
  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type,Authorization,X-Amz-Date,X-Api-Key,X-Amz-Security-Token',
    'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS'
  }

  console.log('=== UPLOAD AUDIO DEBUG ===')
  console.log('httpMethod:', event.httpMethod)
  console.log('headers:', JSON.stringify(event.headers))
  console.log('body:', event.body)

  try {
    // Handle OPTIONS
    if (event.httpMethod === 'OPTIONS') {
      console.log('Handling OPTIONS request')
      return {
        statusCode: 200,
        headers: corsHeaders,
        body: ''
      }
    }

    // Handle POST with simplified processing
    if (event.httpMethod === 'POST') {
      console.log('Handling POST request - DEBUG MODE')
      
      // Parsear body
      let body
      try {
        body = JSON.parse(event.body)
      } catch (error) {
        console.error('Error parsing body:', error)
        return {
          statusCode: 400,
          headers: {
            'Content-Type': 'application/json',
            ...corsHeaders
          },
          body: JSON.stringify({ error: 'Body inválido', details: error.message })
        }
      }

      const { audioData, fileName, contentType, doctorId = 'doctor-demo' } = body

      if (!audioData || !fileName || !contentType) {
        return {
          statusCode: 400,
          headers: {
            'Content-Type': 'application/json',
            ...corsHeaders
          },
          body: JSON.stringify({ 
            error: 'audioData, fileName y contentType son requeridos',
            received: { audioData: !!audioData, fileName, contentType }
          })
        }
      }

      // Simular subida exitosa para debug
      const audioKey = `audio/${doctorId}/${uuidv4()}-${fileName}`

      console.log(`DEBUG: Simulando subida a S3: ${audioKey}`)

      return {
        statusCode: 200,
        headers: {
          'Content-Type': 'application/json',
          ...corsHeaders
        },
        body: JSON.stringify({
          success: true,
          audioKey: audioKey,
          etag: 'debug-etag',
          size: audioData.length,
          doctorId: doctorId,
          timestamp: new Date().toISOString(),
          services: {
            storage: "Amazon S3 (DEBUG MODE)"
          },
          debug: {
            message: "Función funcionando correctamente",
            receivedData: {
              hasAudioData: !!audioData,
              fileName,
              contentType,
              doctorId
            }
          }
        })
      }
    }

    // Other methods
    console.log('Method not allowed:', event.httpMethod)
    return {
      statusCode: 405,
      headers: {
        'Content-Type': 'application/json',
        ...corsHeaders
      },
      body: JSON.stringify({
        error: 'Method not allowed',
        method: event.httpMethod
      })
    }

  } catch (error) {
    console.error('UPLOAD AUDIO ERROR:', error)
    console.error('Stack:', error.stack)
    
    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
        ...corsHeaders
      },
      body: JSON.stringify({
        error: 'Internal server error',
        message: error.message,
        timestamp: new Date().toISOString()
      })
    }
  }
} 